<?php
	$conn = new mysqli("localhost", "root", "", "hotel_db") or die(mysqli_error());
